#include "Scene.hpp"
#include "Engine.hpp"
#include <string>
#include <sstream>


ComponentID GetUniqueComponentID() noexcept
{
    static ComponentID lastID{0u};
    return lastID++;
}

//*********************************************************************************************************************
//**                         TransformComponent                                                                              **
//*********************************************************************************************************************

TransformComponent::TransformComponent(GameObject *parent) : object(parent)
{
    // Log(LOG_INFO, "TransformComponent::TransformComponent()");
    this->rotation = 0;
    this->position = Vec2(0.0f);
    this->scale = Vec2(1.0f);
    this->skew = Vec2(0.0f);
    transform.Identity();
}

TransformComponent::~TransformComponent()
{
    // Log(LOG_INFO, "TransformComponent::~TransformComponent()");
    object = nullptr;
}

void TransformComponent::pointToMouse(float speed, float angleDiff)
{
    Vector2 v = GetMousePosition();
    TurnTo(v.x, v.y, speed, angleDiff);
}

void TransformComponent::TurnTo(float x, float y, float speed, float angleDiff)
{

    rotation = lerpAngleDegrees(rotation, getAngle(position.x, position.y, x, y) + angleDiff, speed);
}

Matrix2D TransformComponent::GetLocalTrasformation()
{

    local_transform.Identity();
    if (skew.x == 0.0f && skew.y == 0.0f)
    {

        if (rotation == 0.0)
        {

            local_transform.Set(scale.x, 0.0, 0.0, scale.y, position.x - pivot.x * scale.x, position.y - pivot.y * scale.y);
        }
        else
        {
            float acos = cos(rotation * RAD);
            float asin = sin(rotation * RAD);
            float a = scale.x * acos;
            float b = scale.x * asin;
            float c = scale.y * -asin;
            float d = scale.y * acos;
            float tx = position.x - pivot.x * a - pivot.y * c;
            float ty = position.y - pivot.x * b - pivot.y * d;

            local_transform.Set(a, b, c, d, tx, ty);
        }
    }
    else
    {

        local_transform.Identity();
        local_transform.Scale(scale.x, scale.y);
        local_transform.Skew(skew.x, skew.y);
        local_transform.Rotate(rotation);
        local_transform.Translate(position.x, position.y);

        if (pivot.x != 0.0f || pivot.y != 0.0f)
        {

            local_transform.tx = position.x - local_transform.a * pivot.x - local_transform.c * pivot.y;
            local_transform.ty = position.y - local_transform.b * pivot.x - local_transform.d * pivot.y;
        }
    }

    return local_transform;
}

Matrix2D Matrix2DMult(const Matrix2D curr, const Matrix2D m)
{

    Matrix2D result;

    result.a = curr.a * m.a + curr.b * m.c;
    result.b = curr.a * m.b + curr.b * m.d;
    result.c = curr.c * m.a + curr.d * m.c;
    result.d = curr.c * m.b + curr.d * m.d;

    result.tx = curr.tx * m.a + curr.ty * m.c + m.tx;
    result.ty = curr.tx * m.b + curr.ty * m.d + m.ty;

    return result;
}

Matrix2D TransformComponent::GetWorldTransformation()
{

    local_transform = GetLocalTrasformation();
    if (object->parent != nullptr)
    {
        Matrix2D mat = object->parent->transform->GetWorldTransformation();
        wordl_transform = Matrix2DMult(local_transform, mat);
        return wordl_transform;
    }
    return local_transform;
}

//*********************************************************************************************************************
//**                         Component                                                                              **
//*********************************************************************************************************************
Component::Component()
{
    object = nullptr;
    depth = 0;
}
Component::~Component()
{
    

    //  Log(LOG_INFO, "Component Destroyed");
}

//*********************************************************************************************************************
//**                         SpriteComponent                                                                              **
//*********************************************************************************************************************

SpriteComponent::SpriteComponent(const std::string &fileName) : Component()
{
    depth = 1;
    this->color = WHITE;
    FlipX = false;
    FlipY = false;
    clip.x = 0;
    clip.y = 0;
    clip.width = 1;
    clip.height = 1;
    graphID = fileName;

    graph = Assets::Instance().getGraph(fileName);
    if (graph)
    {
        clip.x = 0;
        clip.y = 0;
        clip.width = graph->width;
        clip.height = graph->height;
    }
}

void SpriteComponent::OnInit()
{
    object->centerOrigin();
    object->centerPivot();
    object->width = clip.width;
    object->height = clip.height;
}

void SpriteComponent::OnDebug()
{
    // if (object->parent)
    //     DrawText(TextFormat("%s : %s", object->name.c_str(), object->parent->name.c_str()), (int)object->getWorldX(), (int)object->getWorldY(), 5, RED);
    // else
    //     DrawText(TextFormat(" %s ", object->name.c_str()), (int)object->getWorldX(), (int)object->getWorldY(), 5, RED);

    // int x= (int)object->getWorldX() + clip.x - object->getPivotX();
    // int y= (int)object->getWorldY() + clip.y - object->getPivotY();

    //  DrawRectangleLines(x,y,clip.width,clip.height, BLUE);
}

void SpriteComponent::OnDraw()
{
    //  Log(LOG_INFO, "SpriteComponent::OnDraw");

    Matrix2D mat = object->transform->GetWorldTransformation();

    if (graph)
    {
        //  RenderTransformFlip(graph->texture, clip, FlipX, FlipY, color, &mat, 0);
        RenderTransformFlipClip(graph->texture, clip.width, clip.height, clip, FlipX, FlipY, color, &mat, 0);
    }
    else
    {

        DrawCircleLines((int)object->getX(), (int)object->getY(), 1, RED);
        //   Log(LOG_ERROR, "SpriteComponent::OnDraw  %s %f %f ",object->name.c_str() , (int)object->getX(), (int)object->getY());
    }
}

void SpriteComponent::SetClip(float x, float y, float width, float height)
{
    clip.x = x;
    clip.y = y;
    clip.width = width;
    clip.height = height;
}
void SpriteComponent::SetClip(Rectangle c)
{
    clip.x = c.x;
    clip.y = c.y;
    clip.width = c.width;
    clip.height = c.height;
}


TileLayerComponent::TileLayerComponent(int width, int height, int tileWidth, int tileHeight, int spacing, int margin, const std::string &fileName) : tileWidth(tileWidth), tileHeight(tileHeight), spacing(spacing), margin(margin), width(width), height(height)
{

    graph = Assets::Instance().getGraph(fileName.c_str());
    if (!graph)
    {
        Log(LOG_ERROR, "TileLayerComponent::TileLayerComponent  %s ", fileName.c_str());
        isLoad = false;
    }
    isLoad = true;
    graphID = fileName;
    worldWidth = width * tileWidth;
    worldHeight = height * tileHeight;
    // tileMap.reserve(width * height + 1);
    for (int i = 0; i < width * height; i++)
    {
        tileMap.push_back(-1);
    }
}


void TileLayerComponent::PaintRectangle(int x, int y, int w, int h, int id)
{
    if (!isLoad || !isWithinBounds(x, y))
        return;
    for (int i = x; i < x + w; ++i)
    {
        for (int j = y; j < y + h; ++j)
        {
            setTile(i, j, id);
        }
    }
}

void TileLayerComponent::PaintCircle(int x, int y, int radius, int id)
{
    if (!isLoad || !isWithinBounds(x, y))
        return;

    int rsq = radius * radius;
    for (int i = x - radius; i <= x + radius; ++i)
    {
        for (int j = y - radius; j <= y + radius; ++j)
        {
            int dx = i - x;
            int dy = j - y;
            if (dx * dx + dy * dy <= rsq)
            {
                setTile(i, j, id);
            }
        }
    }
}
void TileLayerComponent::OnInit()
{
            object->originX=0;
            object->originY=0;
            object->width=width*tileWidth;
            object->height=height*tileHeight;
            object->bound.x=0;
            object->bound.y=0;
            object->bound.width=width*tileWidth;
            object->bound.height=height*tileHeight;
           // object->setDebug( SHOW_BOX |  SHOW_BOUND );

}

void TileLayerComponent::OnDebug()
{
    Log(LOG_INFO, "TileLayerComponent::OnDebug");

    if (!isLoad)
        return;

    DrawRectangle(0,0,width*tileWidth,height*tileHeight, RED);
}

void TileLayerComponent::OnDraw()
{
    //  Log(LOG_INFO, "TileLayerComponent::OnDraw");
    if (!isLoad || !graph)
        return;
    if (width == 0 || height == 0 || tileWidth == 0 || tileHeight == 0)
    {
        Log(LOG_ERROR, "TileLayerComponent::OnDraw %d %d  %d %d", width, height, tileWidth, tileHeight);
        isLoad = false;
        return;
    }

    Scene *scene = Scene::Instance();


    // auto startTime = std::chrono::high_resolution_clock::now();

    


//loop in view
float zoom = scene->camera.zoom;
Vector2 offset = scene->camera.offset;
Vector2 target = scene->camera.target;
Rectangle cameraView = {
    -offset.x/zoom + target.x - (scene->windowSize.x/2.0f/zoom),
    -offset.y/zoom + target.y - (scene->windowSize.y/2.0f/zoom),
    (float)scene->windowSize.x/zoom + (offset.x/zoom),
    (float)scene->windowSize.y/zoom + (offset.y/zoom)
};

int startX = (int)(cameraView.x / tileWidth);
int startY = (int)(cameraView.y / tileHeight);
int endX = (int)((cameraView.x + cameraView.width) / tileWidth) + 1;
int endY = (int)((cameraView.y + cameraView.height) / tileHeight) + 1;

    startX = Clamp(startX, 0, width);
    startY = Clamp(startY, 0, height);
    endX = Clamp(endX, 0, width);
    endY = Clamp(endY, 0, height);

    for (int i = startY; i < endY; i++)
    {
        for (int j = startX; j < endX; j++)
        {
            float posX = (float)(j * tileWidth);
            float posY = (float)(i * tileHeight);
            Rectangle tileRect = {posX, posY, tileWidth, tileHeight};
            if (!scene->inView(tileRect))
                    continue;

            int tile = getTile(j, i);
            if (tile != -1)
            {

                RenderTile(graph->texture,
                           posX, posY,
                           tileWidth, tileHeight,
                           getClip(tile),
                           false, false, 0);
                    
            }
            // 736
        }
    }
//  auto endTime = std::chrono::high_resolution_clock::now();
// auto deltaTime = std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime).count() / 1000000.0f;
   
//     Log(LOG_INFO, "loop in view %f",deltaTime);


// //loop all

//   startTime = std::chrono::high_resolution_clock::now();


//     for (int i = 0; i < height; i++)
//     {
//         for (int j = 0; j < width; j++)
//         {
//                float  posX=(float)(j * tileWidth );
//                float  posY=(float)(i * tileHeight);
//                Rectangle tileRect = {posX, posY, tileWidth, tileHeight};
//                if (!scene->inView(tileRect))
//                     continue;
                
                

//                      int tile= getTile(j,i) ;
//                      if (tile!=-1)
//                      {

//                         RenderTile(graph->texture,
//                                     posX,posY,
//                                     tileWidth,tileHeight,
//                                     getClip(tile),
//                                     false,false,0);
                        
//                     }
//                     //115 ;)

//         }
//     }
//  endTime = std::chrono::high_resolution_clock::now();
//  deltaTime = std::chrono::duration_cast<std::chrono::microseconds>(endTime - startTime).count() / 1000000.0f;

//     Log(LOG_INFO, "loop all %f",deltaTime);




  

    //  //   Log(LOG_INFO, "TileLayerComponent::OnDraw %d %d  %d %d", width, height,tileWidth, tileHeight);
}

void TileLayerComponent::loadFromArray(const int *tiles)
{
    tileMap.clear();
    int arraSize = (tileWidth * tileHeight);
    for (int i = 0; i < arraSize; i++)
    {
        tileMap.push_back(tiles[i]);
    }
}
void TileLayerComponent::loadFromCSVFile(const std::string &filename)
{
    //    m_tileMap.clear();
    //    std::string tmp;
    //    char delim = ','; // Ddefine the delimiter to split by
    //    std::ifstream myFile(filename);
    //    std::getline(myFile,tmp,delim);
    //    while (std::getline(myFile,tmp,delim))
    //   {
    //      int index = std::stoi(tmp);
    //      m_tileMap.push_back(index);
    //    }

    if (!FileInPath(filename))
    {
        Log(LOG_ERROR, "The file  %s dont exists ", filename.c_str());
        return;
    }
    std::string path = GetPath(filename);
    char *text = LoadFileText(path.c_str());

    if (text == nullptr)
    {
        Log(LOG_ERROR, " Reading  %s", filename.c_str());
        return;
    }

    std::istringstream file(text);
    tileMap.clear();
    tileMap.reserve(width * height);

    std::string line;
    while (std::getline(file, line))
    {
        std::istringstream lineStream(line);
        std::string cell;
        while (std::getline(lineStream, cell, ','))
        {
            int tile = std::stoi(cell);
            tileMap.push_back(tile);
        }
    }

    UnloadFileText(text);
}

void TileLayerComponent::loadFromString(const std::string &text,int shift)
{
    std::istringstream file(text);
    tileMap.clear();
    tileMap.reserve(width * height);

    std::string line;
    while (std::getline(file, line))
    {
        std::istringstream lineStream(line);
        std::string cell;
        while (std::getline(lineStream, cell, ','))
        {
            int tile = std::stoi(cell) + shift;
            tileMap.push_back(tile);
        }
    }
}

std::string TileLayerComponent::getCSV() const
{
    std::ostringstream csvStream;
    for (size_t i = 0; i < tileMap.size(); ++i)
    {
        csvStream << tileMap[i];

        if (i < tileMap.size() - 1)
        {
            csvStream << ",";
        }
    }
    return csvStream.str();
}

void TileLayerComponent::saveToCSVFile(const std::string &filename)
{
    std::ostringstream file;

    for (int y = 0; y < height; ++y)
    {
        for (int x = 0; x < width; ++x)
        {
            int tile = tileMap[y * width + x];
            file << tile;
            if (x < width - 1)
            {
                file << ",";
            }
        }
        file << "\n";
    }

    std::string fileContent = file.str();

    bool success = SaveFileText(filename.c_str(), const_cast<char *>(fileContent.c_str()));

    if (!success)
    {
        Log(LOG_ERROR, "Saving file: %s", filename.c_str());
    }
}

void TileLayerComponent::setTile(int x, int y, int tile)
{
    if (!isLoad || !isWithinBounds(x, y))
        return;

    int index = (int)(x + y * width);
    tileMap[index] = tile;
}
int TileLayerComponent::getTile(int x, int y)
{
    if (!isLoad || !isWithinBounds(x, y))
        return -1;
    int index = (int)(x + y * width);
    return tileMap[index];
}

void TileLayerComponent::createSolids()
{
     int count=0;
     for (int x = 0; x < width; x++)
        {
            for (int y = 0; y < height; y++)
            {
                int tile= getTile(x,y) ;
                if (tile!=-1)
                {
                    if (tile>=1)
                    {

                     GameObject *solid = new GameObject("solid",2);
                    solid->solid=true;
                    solid->prefab=true;
                    solid->transform->position.x=x*tileWidth,
                    solid->transform->position.y=y*tileHeight;

                    solid->width = tileWidth;
                    solid->height= tileHeight;

                    solid->originX=0;// (tileWidth/2) + (tileWidth/2)  +14;
                    solid->originY=0;// (tileHeight/2) + (tileHeight/2)+14;
                    solid->transform->pivot.x=0;
                    solid->transform->pivot.y=0;

                    solid->UpdateWorld();
              

     

                    
//                    solid->setDebug( SHOW_BOX );

                    Scene::Instance()->AddGameObject(solid);

                    }

                    count++;
                }
            }
        }
        
}

Rectangle TileLayerComponent::getClip(int id)
{
    Rectangle clip;
    if (!graph || !isLoad)
    {
        Log(LOG_ERROR, "TileLayerComponent::getClip - Graph is null");
        return clip;
    }

    int columns = (int)floor(graph->width / tileWidth);
    // int rows = (int)floor(graph->height / tileHeight);

    int pRow = id / columns;
    int pFrame = id % columns;

    float sourcex = margin + (spacing + tileWidth) * pFrame;
    float sourcey = margin + (spacing + tileHeight) * pRow;

    clip.x = sourcex;
    clip.y = sourcey;
    clip.width = tileWidth;
    clip.height = tileHeight;

    return clip;
}

void TileLayerComponent::clear()
{
    tileMap.clear();
}

void TileLayerComponent::addTile(int index)
{
    tileMap.push_back(index);
}

//*********************************************************************************************************************
//**                         ANIMATION                                                                              **
//*********************************************************************************************************************

Animation::Animation(const std::string &graphID, int rows, int columns, int frameCount, float frameDuration) : frameCount(frameCount),
                                                                                                               currentFrame(0),
                                                                                                               frameDuration(frameDuration),
                                                                                                               currentTime(0),
                                                                                                               isReversed(false), rows(rows),
                                                                                                               columns(columns)

{
    this->graphID = graphID;
    graph = Assets::Instance().getGraph(graphID);
    if (graph)
    {
        imageWidth = graph->texture.width;
        imageHeight = graph->texture.height;
        // Log(LOG_INFO, "Animation::Animation() : graphID %s %d %d", graphID.c_str(), imageWidth, imageHeight);
    }
    else
    {
        Log(LOG_ERROR, "Animation::Animation() : graphID not found %s", graphID.c_str());
    }
}

Rectangle Animation::GetFrame()
{
    Rectangle rect;
    if (graph == nullptr)
    {
        Log(LOG_ERROR, "Animation::GetFrame() : graph is null");
        return rect;
    }
    rect.width = imageWidth / columns;
    rect.height = imageHeight / rows;
    rect.x = (currentFrame % columns) * rect.width;
    rect.y = (currentFrame / columns) * rect.height;
    return rect;
}

void Animation::Update(float deltaTime, AnimationMode mode)
{
    if (!graph)
        return;
    currentTime += deltaTime;

    if (mode == AnimationMode::Loop)
    {
        while (currentTime >= frameDuration)
        {
            currentFrame = (currentFrame + 1) % frameCount;
            currentTime -= frameDuration;
        }
    }
    else if (mode == AnimationMode::PingPong)
    {
        int frameIndex = currentFrame;
        int frameIncrement = isReversed ? -1 : 1;

        while (currentTime >= frameDuration)
        {
            frameIndex += frameIncrement;

            if (frameIndex < 0)
            {
                frameIndex = 1;
                isReversed = false;
            }
            else if (frameIndex >= frameCount)
            {
                frameIndex = frameCount - 2;
                isReversed = true;
            }

            currentTime -= frameDuration;
        }

        currentFrame = frameIndex;
    }
    else if (mode == AnimationMode::Stop)
    {
        if (currentFrame < frameCount - 1)
        {
            while (currentTime >= frameDuration)
            {
                currentFrame++;
                currentTime -= frameDuration;
            }
        }
    }
    else if (mode == AnimationMode::Once)
    {
        if (currentFrame < frameCount - 1)
        {
            while (currentTime >= frameDuration)
            {
                currentFrame++;
                currentTime -= frameDuration;
            }
        }
    }
}

//*********************************************************************************************************************
//**                         ANIMATOR                                                                               **
//*********************************************************************************************************************

Animator::Animator() : Component(), currentAnimation(""), nextAnimation(""),
                       isPlaying(true),
                       mode(AnimationMode::Loop)
{
    sprite = nullptr;
    object = nullptr;
    currentFrame = 0;
    frameCount = 0;
    frameDuration = 0;
    currentTime = 0;
    isReversed = false;
    isLoad = true;
}

void Animator::OnDestroy()
{
    for (auto &pair : animations)
    {
        delete pair.second;
    }
    animations.clear();
}


void Animator::OnUpdate(float deltaTime)
{
    if (animations.size() == 0 || !isLoad)
        return;

    if (!sprite)
    {
        sprite = object->GetComponent<SpriteComponent>();
        if (!sprite)
        {
            Log(LOG_ERROR, "Animator::OnUpdate() : SpriteComponent not found");
            isLoad = false;
            return;
        }
    }

    //   Log(LOG_INFO, "Animator::OnUpdate() : %s", object->name.c_str());

    if (isPlaying)
    {
        Animation *animation = GetAnimation();
        if (!animation)
            return;
        animation->Update(deltaTime, mode);

        currentFrame = animation->currentFrame;
        currentTime = animation->currentTime;
        frameCount = animation->frameCount;
        frameDuration = animation->frameDuration;
        isReversed = animation->isReversed;

        if (nextAnimation != "" && animation->currentFrame == animation->frameCount - 1)
        {
            currentAnimation = nextAnimation;
            nextAnimation = "";
            animation->currentFrame = 0;
            animation->currentTime = 0;
            Play();
        }
        // verifica se a animação atual terminou de ser reproduzida
        if (animation->currentFrame == animation->frameCount - 1)
        {
            if (mode == AnimationMode::Loop)
            {
                animation->currentFrame = 0; // reinicia a animação
                animation->currentTime = 0;
            }
            else if (mode == AnimationMode::PingPong)
            {
                animation->isReversed = true; // inverte a reprodução da animação
            }
        }

        // verifica se a animação atual terminou de ser reproduzida no modo PingPong
        if (animation->currentFrame == 0 && animation->isReversed)
        {
            if (mode == AnimationMode::PingPong)
            {
                animation->isReversed = false; // inverte a reprodução da animação de volta
            }
        }
    }

    Animation *animation = GetAnimation();
    if (!animation)
        return;

    if (sprite)
    {

        Rectangle frameRectangle = animation->GetFrame();
        sprite->clip.x = frameRectangle.x;
        sprite->clip.y = frameRectangle.y;
        sprite->clip.width = frameRectangle.width;
        sprite->clip.height = frameRectangle.height;
        sprite->graph = animation->graph;
    }
}

void Animator::Play()
{
    isPlaying = true;
}

void Animator::Pause()
{
    isPlaying = false;
}

void Animator::Stop()
{
    isPlaying = false;
    if (animations.size() == 0 || !isLoad)
        return;
    Animation *animation = GetAnimation();
    if (!animation)
        return;

    animation->currentFrame = 0;
    animation->currentTime = 0;
}

void Animator::SetAnimation(const std::string &name, bool now)
{
    if (animations.size() == 0 || !isLoad)
        return;
    if (now)
    {
        currentAnimation = name;
        nextAnimation = "";
        Play();
    }
    else if (currentAnimation != name)
    {
        if (nextAnimation == "")
        {
            nextAnimation = name; // marca a próxima animação a ser reproduzida
        }
        else
        {
            nextAnimation = name; // sobrescreve a próxima animação marcada
        }
    }
}
Animation *Animator::GetAnimation()
{
    auto it = std::find_if(animations.begin(), animations.end(),
                           [this](const std::pair<std::string, Animation *> &pair)
                           {
                               return pair.first == currentAnimation;
                           });
    if (it != animations.end())
    {
        return it->second;
    }
    else
    {

        return animations.front().second;
    }
}

void Animator::AddAnimation(const std::string &name, Animation *animation)
{
    animations.push_back(std::make_pair(name, animation));
    if (currentAnimation == "")
    {
        currentAnimation = name;
    }
    OnUpdate(0);
}

void Animator::Add(const std::string &name, const std::string &graph, int rows, int columns, int frameCount, float framesPerSecond)
{
    float frameDuration = 1.0f / framesPerSecond;
    Animation *animation = new Animation(graph, rows, columns, frameCount, frameDuration);
    AddAnimation(name, animation);
}

void Animator::SetMode(AnimationMode mode)
{
    this->mode = mode;
    if (animations.size() == 0 || !isLoad)
        return;
    Animation *animation = GetAnimation();
    if (!animation)
        return;
    animation->currentFrame = 0;
    animation->currentTime = 0;
    animation->isReversed = false;
}
void Animator::OnInit()
{
    if (object != nullptr)
    {
        if (object->HasComponent<SpriteComponent>())
        {
            sprite = object->GetComponent<SpriteComponent>();
        }
        else
        {
            Log(LOG_ERROR, "SpriteComponent::OnInit() : GameObject has no SpriteComponent");
            isLoad = false;
        }
    }
}

void Animator::OnDebug()
{
    // Log(LOG_INFO, "Animator::OnDebug()");
}

//*********************************************************************************************************************
//**                         GameObject                                                                              **
//*********************************************************************************************************************

static unsigned long NewGameObjectID()
{
    static unsigned long id = 0;
    return id++;
}

GameObject::GameObject() : name("GameObject"),
                           alive(true), visible(true), active(true),
                           layer(1)
{
    // Log(LOG_INFO, "GameObject created");
    parent = nullptr;
    id = NewGameObjectID();
    transform = new TransformComponent(this);
    UpdateWorld();
    bound.x = 0;
    bound.y = 0;
    width = 1;
    height = 1;
    originX = 0;
    originY = 0;
    solid = false;
    prefab = false;
    persistent = false;
    collidable = true;
    pickable = false;

    word_position.x = transform->position.x;
    word_position.y = transform->position.y;

    layer = 0;
    scriptName = "";
    _x = 0;
    _y = 0;

    debugMask = 0;
}

GameObject::GameObject(const std::string &Name) : GameObject()
{

    name = Name;
}

GameObject::GameObject(const std::string &Name, int layer) : GameObject()
{
    this->layer = layer;
    name = Name;
}

void GameObject::OnReady()
{

}
void GameObject::OnPause()
{
   
}

void GameObject::OnRemove()
{
}

void GameObject::Encapsulate(float x, float y)
{
    if (bbReset)
    {
        x1 = x2 = x;
        y1 = y2 = y;
        bbReset = false;
    }
    else
    {
        if (x < x1)
            x1 = x;
        if (x > x2)
            x2 = x;
        if (y < y1)
            y1 = y;
        if (y > y2)
            y2 = y;

        bound.x = x1;
        bound.y = y1;
        bound.width = (x2 - x1);
        bound.height = (y2 - y1);
    }
}



Vector2 ApplyMatrixToPoint(const Matrix2D &matrix, float x, float y)
{
    Vector2 transformedPoint;
    transformedPoint.x = x * matrix.a + y * matrix.c + matrix.tx;
    transformedPoint.y = x * matrix.b + y * matrix.d + matrix.ty;

    return transformedPoint;
}

void GameObject::UpdateWorld()
{
    Matrix2D mat = transform->GetWorldTransformation();
    word_position = mat.TransformCoords();

    float w = width  *  transform->scale.x;
    float h = height *  transform->scale.y;
    radius = std::min(w, h) / 2.0f;

    bbReset = true;
    float newX = word_position.x;
    float newY = word_position.y;
    const auto tx1 = 0;
    const auto ty1 = 0;
    const auto tx2 = w;
    const auto ty2 = h;

    if (GetWorldAngle() != 0.0f)
    {

        const auto cost = cosf(-GetWorldAngle() * DEG2RAD);
        const auto sint = sinf(-GetWorldAngle() * DEG2RAD);

        Encapsulate(tx1 * cost - ty1 * sint + newX, tx1 * sint + ty1 * cost + newY);
        Encapsulate(tx2 * cost - ty1 * sint + newX, tx2 * sint + ty1 * cost + newY);
        Encapsulate(tx2 * cost - ty2 * sint + newX, tx2 * sint + ty2 * cost + newY);
        Encapsulate(tx1 * cost - ty2 * sint + newX, tx1 * sint + ty2 * cost + newY);
    }
    else
    {

        Encapsulate(tx1 + newX, ty1 + newY);
        Encapsulate(tx2 + newX, ty1 + newY);
        Encapsulate(tx2 + newX, ty2 + newY);
        Encapsulate(tx1 + newX, ty2 + newY);
    }

    for (auto &c : children)
    {
        c->UpdateWorld();
    }
}
void GameObject::OnCollision(GameObject *other)
{

  
    // Log(LOG_INFO, "OnColide %s with %s ", name.c_str(), other->name.c_str());
}

void GameObject::sendMensageAll()
{
    if (!scene)
        return;

    for (auto &c : scene->gameObjects)
    {
        if (c == this)
            continue;
        if (!c->alive)
            continue;
      
    }

    for (auto &c : children)
    {
        c->sendMensageAll();
    }
}

void GameObject::setDebug(int mask)
{
    debugMask = mask;
}

void GameObject::sendMensageTo(const std::string &name)
{
    if (!scene)
        return;

    for (auto &c : scene->gameObjects)
    {
        if (!c->alive)
            continue;
        if (c->name == name)
        {
                    }
    }

    for (auto &c : children)
    {
        c->sendMensageTo(name);
    }
}

void GameObject::Update(float dt)
{
    
    if (solid)
        return;

    UpdateWorld();



    for (auto &c : m_components)
    {
        c->OnUpdate(dt);
    }

    for (auto &c : children)
    {
        c->Update(dt);
    }
}

bool GameObject::place_free(float x, float y)
{
    if (!scene)
        return true;
    return scene->place_free(this, x, y);
}

bool GameObject::place_meeting(float x, float y, const std::string &name)
{
    if (!scene)
        return false;
    return scene->place_meeting(this, x, y, name);
}

bool GameObject::place_meeting_layer(float x, float y, int layer)
{

    if (!scene)
        return false;
    return scene->place_meeting_layer(this, x, y, layer);
}

bool GameObject::collideWith(GameObject *e, float x, float y)
{
    if (!scene || !e)
        return false;
    if (e == this)
        return false;

    _x = this->transform->position.x;
    _y = this->transform->position.y;
    this->transform->position.x = x;
    this->transform->position.y = y;

    if (
        x - this->getWorldOriginX() + width > e->getWorldX() - e->getWorldOriginX() &&
        y - this->getWorldOriginY() + height > e->getWorldY() - e->getWorldOriginY() &&
        x - this->getWorldOriginX() < e->getWorldX() - e->getWorldOriginX() + e->width &&
        y - this->getWorldOriginY() < e->getWorldY() - e->getWorldOriginY() + e->height)
    {
        this->transform->position.x = _x;
        this->transform->position.y = _y;
        OnCollision(e);
        e->OnCollision(this);
        return true;
    }
    this->transform->position.x = _x;
    this->transform->position.y = _y;
    return false;
}

void GameObject::centerPivot()
{

    if (HasComponent<SpriteComponent>())
    {
        auto sprite = GetComponent<SpriteComponent>();
        transform->pivot.x = sprite->clip.width / 2.0f;
        transform->pivot.y = sprite->clip.height / 2.0;
        //  Log(LOG_INFO, "Pivot %s set to %f %f", name.c_str(), transform->pivot.x, transform->pivot.y);
        // Log(LOG_INFO, "Size %s set to %f %f", name.c_str(), sprite->clip.width, sprite->clip.height);
    }
    else
    {

        transform->pivot.x = (width / 2.0f);
        transform->pivot.y = (height / 2.0f);
        // Log(LOG_INFO, "Pivot %s set to %f %f", name.c_str(), transform->pivot.x, transform->pivot.y);
    }
}

void GameObject::centerOrigin()
{

    if (HasComponent<SpriteComponent>())
    {
        auto sprite = GetComponent<SpriteComponent>();
        width = (int)sprite->clip.width / 2 * transform->scale.x;
        height = (int)sprite->clip.height / 2 * transform->scale.y;
        originX = -(int)(width / 2.0f) + (width / 2.0f);
        originY = -(int)(height / 2.0f) + (height / 2.0f);
    }
    else
    {

        originX = (width / 2.0f);
        originY = (height / 2.0f);
        // Log(LOG_INFO, "Pivot %s set to %f %f", name.c_str(), transform->pivot.x, transform->pivot.y);
    }
}

void GameObject::Debug()
{

    if (!debugMask)
        return;

    bool isOriginEnabled = (debugMask & SHOW_ORIGIN) != 0;
    bool isBoxCollideEnabled = (debugMask & SHOW_BOX) != 0;

    float finalRad = radius / 4.0f;
    if (finalRad < 0.5f)
        finalRad = 0.5f;

   

    int bX = (int)getX();
    int bY = (int)getY();

    int cx = bX + originX;
    int cy = bY + originY;
    int cw = width ;
    int ch = height ;

    if (isBoxCollideEnabled)
        DrawRectangleLines( cx,  cy, cw , ch , WHITE);
    if (isOriginEnabled)
        DrawCircle(cx, cy, finalRad, WHITE);

    if (!solid)
    {

        Vec2 p;
        if (!parent)
            p = GetLocalPoint(transform->pivot.x, transform->pivot.y);
        else
            p = GetWorldPoint(transform->pivot.x, transform->pivot.y);

        bool isPivotEnabled = (debugMask & SHOW_PIVOT) != 0;
        bool isTrasnformEnabled = (debugMask & SHOW_TRANSFORM) != 0;

        if (isPivotEnabled)
            DrawCircle((int)p.x, (int)p.y, finalRad, LIME);

        float newX = word_position.x;
        float newY = word_position.y;
        const auto tx1 = 0;
        const auto ty1 = 0;
        const auto tx2 = width  * 2.0f * transform->scale.x;
        const auto ty2 = height * 2.0f * transform->scale.y;

        if (isTrasnformEnabled)
        {
            if (GetWorldAngle() != 0.0f)
            {

                const auto cost = cosf(-GetWorldAngle() * DEG2RAD);
                const auto sint = sinf(-GetWorldAngle() * DEG2RAD);
                float x1 = tx1 * cost - ty1 * sint + newX;
                float y1 = tx1 * sint + ty1 * cost + newY;
                float x2 = tx2 * cost - ty1 * sint + newX;
                float y2 = tx2 * sint + ty1 * cost + newY;
                float x3 = tx2 * cost - ty2 * sint + newX;
                float y3 = tx2 * sint + ty2 * cost + newY;
                float x4 = tx1 * cost - ty2 * sint + newX;
                float y4 = tx1 * sint + ty2 * cost + newY;
                DrawLine(x1, y1, x2, y2, LIME);
                DrawLine(x1, y1, x4, y4, LIME);
                DrawLine(x3, y3, x4, y4, LIME);
                DrawLine(x2, y2, x3, y3, LIME);
            }
            else
            {
                DrawLine(tx1 + newX, ty1 + newY, tx2 + newX, ty1 + newY, LIME);
                DrawLine(tx1 + newX, ty1 + newY, tx1 + newX, ty2 + newY, LIME);
                DrawLine(tx2 + newX, ty2 + newY, tx1 + newX, ty2 + newY, LIME);
                DrawLine(tx2 + newX, ty2 + newY, tx2 + newX, ty1 + newY, LIME);
            }
        }
    }

    bool isComponentsEnable = (debugMask & SHOW_COMPONENTS) != 0;
    bool isBoundEnable = (debugMask & SHOW_BOUND) != 0;

    if (isBoundEnable)
        DrawRectangleLinesEx(bound, 1.5f, MAGENTA);

    if (isComponentsEnable)
    {
        for (auto &c : m_components)
        {
            c->OnDebug();
        }
    }

    for (auto &c : children)
    {
        c->Debug();
    }
}
void GameObject::Render()
{



    for (auto &c : m_components)
    {
        c->OnDraw();
    }

    
    for (auto &c : children)
    {
        c->Render();
    }

    // Log(LOG_INFO, "Render %s %f %f", name.c_str(),getX(),getY());
}

GameObject::~GameObject()
{
    // Log(LOG_INFO, "[CPP] GameObject (%s) destroyed", name.c_str());

    for (auto &c : m_components)
    {
        if (c)
        {
            c->OnDestroy();
            delete c;
        }
    }

    for (auto &c : children)
    {
        if (c)
        {
            delete c;
        }
    }
    children.clear();

}

Vec2 GameObject::GetWorldPoint(float _x, float _y)
{

    return transform->wordl_transform.TransformCoords(Vec2(_x, _y));
}

Vec2 GameObject::GetWorldPoint(Vec2 p)
{
    return transform->wordl_transform.TransformCoords(p);
}

Vec2 GameObject::GetLocalPoint(Vec2 p)
{
    return transform->local_transform.TransformCoords(p);
}

Vec2 GameObject::GetLocalPoint(float x, float y)
{
    return transform->local_transform.TransformCoords(Vec2(x, y));
}


GameObject *GameObject::addChild(GameObject *e)
{
    children.push_back(e);
    e->parent = this;
    return e;
}
